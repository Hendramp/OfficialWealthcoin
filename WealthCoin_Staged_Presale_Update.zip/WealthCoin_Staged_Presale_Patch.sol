// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/*
  WealthCoin staged presale logic patch.

  Add this logic to the deployed token contract source before redeploying,
  or use it as the reference for a new upgrade/deployment. A non-upgradeable
  contract already deployed on Polygon cannot be changed in-place.

  Published presale table:
  Stage 1: 100 POL = 500,000 WTC  => 1 POL = 5,000 WTC
  Stage 2: 100 POL = 400,000 WTC  => 1 POL = 4,000 WTC
  Stage 3: 100 POL = 300,000 WTC  => 1 POL = 3,000 WTC
  Stage 4: 100 POL = 225,000 WTC  => 1 POL = 2,250 WTC
  Stage 5: 100 POL = 150,000 WTC  => 1 POL = 1,500 WTC
*/

abstract contract WealthCoinStagedPresalePatch {
    uint256 public constant WTC_DECIMALS = 1e18;
    uint256 public constant PRESALE_ALLOCATION = 21_000_000 * WTC_DECIMALS;
    uint256 public constant STAGE_CAP = PRESALE_ALLOCATION / 5;

    // Rates are WTC tokens per 1 POL/MATIC, without token decimals.
    uint256[5] internal presaleRates = [uint256(5000), 4000, 3000, 2250, 1500];
    uint256[5] internal stageDurations = [uint256(7 days), 8 days, 8 days, 8 days, 8 days];

    uint256 public presaleStartTime;
    uint256 public presaleSold;
    bool public presaleActive;
    address payable public presaleReceiver;

    event PresaleStarted(uint256 startTime);
    event PresaleStatusChanged(bool active);
    event PresalePurchase(address indexed buyer, uint256 polAmount, uint256 wtcAmount, uint8 stage);

    modifier onlyOwner() virtual;

    // Your token contract already needs these functions available internally.
    function balanceOf(address account) public view virtual returns (uint256);
    function _transfer(address from, address to, uint256 amount) internal virtual;

    function _initPresale(address payable receiver) internal {
        require(receiver != address(0), "Invalid receiver");
        presaleReceiver = receiver;
        presaleStartTime = block.timestamp;
        presaleActive = true;
        emit PresaleStarted(block.timestamp);
    }

    function setPresaleActive(bool active) external onlyOwner {
        presaleActive = active;
        emit PresaleStatusChanged(active);
    }

    function setPresaleReceiver(address payable receiver) external onlyOwner {
        require(receiver != address(0), "Invalid receiver");
        presaleReceiver = receiver;
    }

    function currentPresaleStage() public view returns (uint8) {
        // Advance by sold amount.
        uint8 soldStage = uint8(presaleSold / STAGE_CAP) + 1;
        if (soldStage > 5) soldStage = 5;

        // Advance by elapsed stage duration.
        uint256 elapsed = block.timestamp > presaleStartTime ? block.timestamp - presaleStartTime : 0;
        uint256 running;
        uint8 timeStage = 1;
        for (uint8 i = 0; i < 5; i++) {
            running += stageDurations[i];
            if (elapsed < running) {
                timeStage = i + 1;
                break;
            }
            timeStage = 5;
        }

        // Use whichever is further along so the presale cannot stay in an early bonus stage forever.
        return soldStage > timeStage ? soldStage : timeStage;
    }

    function tokensPerMatic() public view returns (uint256) {
        return presaleRates[currentPresaleStage() - 1];
    }

    function previewBuy(uint256 polWeiAmount) public view returns (uint256) {
        return (polWeiAmount * tokensPerMatic());
    }

    function buy() external payable {
        require(presaleActive, "Presale inactive");
        require(msg.value > 0, "Send POL");
        require(presaleSold < PRESALE_ALLOCATION, "Presale sold out");
        require(presaleReceiver != address(0), "Receiver not set");

        uint8 stage = currentPresaleStage();
        uint256 wtcAmount = msg.value * presaleRates[stage - 1];

        uint256 remaining = PRESALE_ALLOCATION - presaleSold;
        require(wtcAmount <= remaining, "Amount exceeds presale remaining");
        require(balanceOf(address(this)) >= wtcAmount, "Contract lacks WTC");

        presaleSold += wtcAmount;
        _transfer(address(this), msg.sender, wtcAmount);

        (bool sent, ) = presaleReceiver.call{value: msg.value}("");
        require(sent, "POL transfer failed");

        emit PresalePurchase(msg.sender, msg.value, wtcAmount, stage);
    }
}
